# Hostel-Management-System
A system built for hostel room allocation for our College(HITK) as a part of Internship.

### For more details regarding the system please refer to SDD, SRS, UserManual of the system in Documentation folder.
